/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <libintl.h>
#include <locale.h>

#include "common.h"

#define _i18n(x) gettext(x)
#define N_(x) (x)

#define T_FUNC_IN ;
#define T_FUNC_OUT ;

#ifndef _P_VERSION
#define _P_VERSION "0.7.8"
#endif

#ifndef _P_APPNAME
#define _P_APPNAME "peez2"
#endif

#define _DEFAULT_DRIVE "/dev/hda"

//

#define _PARTED_OVERHEAD 0
#define _RESIZE2FS_OVERHEAD  32256
#define _NFSRESIZE_OVERHEAD  32256

#define _MEGABYTE_FACTOR  1048576

#define APP_ACTION_SHOW 	1
#define APP_ACTION_WIZARD	2
#define APP_ACTION_EXECUTE	4
#define APP_ACTION_VALIDATE	8
#define APP_ACTION_SHOWDISKS	16

#define DISK_UNKNOWN   0
#define DISK_FULL      1
#define DISK_WIN       2
#define DISK_LIN       4
#define DISK_UNPART    8
#define DISK_CLEAN     16
#define DISK_EMPTY     32
#define DISK_FREESPACE     64
#define DISK_FREESPACE_CT 128

#define ACTION_NONE   			0
#define ACTION_CREATE_PART_TABLE       	1
#define ACTION_ALL_FOR_ME     		2
#define ACTION_PARTIAL_FOR_ME  		4
#define ACTION_FITME  			8
#define ACTION_RESIZE			16
#define ACTION_REPLACE			32
#define ACTION_MAKEMYDAY		128

#define CONFACTION_NONE   			0
#define CONFACTION_WINBOOT       	1
#define CONFACTION_LINBOOT       	2
#define CONFACTION_PARTIAL_FOR_ME  		4

/* Global vars */

extern int _N_DRIVES;
extern int _N_SEL_DRIVE;
extern char _SELECTED_DRIVE[];
extern char *_DRIVE_LIST[25];
extern char *_DRIVE_LIST_NAMES[25];
extern char _DISK_STATUS;
extern long long int _MINIMAL_SPACE;
extern int _N_RAW_PARTS;

extern long long int _LAYOUT[10];


extern long long int _MIN_SPACE;
extern long long int _MAX_SPACE;

extern char _ACTIONS[16];
extern int _N_ACTIONS;
extern char _CONFACTIONS[16];
extern int _N_CONFACTIONS;
extern char _APP_ACTION;

extern char _BE_VERBOSE;
extern char _BE_INTERACTIVE;
extern char _NO_MAKE_PARTITIONS;

extern char *_FRONTEND_ID;

extern char *OUT_FILE_NAME;
extern char OUT_FILE;

extern char **luser_index;
