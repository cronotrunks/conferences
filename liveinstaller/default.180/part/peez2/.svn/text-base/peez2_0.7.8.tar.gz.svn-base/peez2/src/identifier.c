/***************************************************************************
                          identifier.c  -  description
                             -------------------
    begin                : mar ene 11 09:26:58 CET 2005
    copyright            : (C) 2005 by Augusto Beiro
    email                : abeiro@activasistemas.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <string.h>
#include "common.h"

char *TOKENS_WIN98[3] = {
    "MSWIN4.1", "MSDOS", "WINBOOT"
};
char *TOKENS_FAT32_DATA[1] = {
    "FAT32"
};

char *TOKENS_FAT16_DATA[1] = {
    "FAT16"
};

char *TOKENS_FAT32_WINXP[3] = {
    "MSWIN4.1",
    "NTLDR",
    "FAT32"
};

char *TOKENS_NTFS_WINXP[2] = {
    "NTFS",
    "NTLDR"
};

char *SYSTEM_TYPE[7] = {
    "Unknow",
    "Linux OS",
    "Windows 9x",
    "Windows XP/2000 FAT32",
    "FAT32 data",
    "FAT16 data",
    "Windows XP/2000 NTFS"
};

int search_token(char *token, char *partition)
{

    FILE *a;
    char chunk[1025];
    int limit = 512;
    int i = 0, j = 0;
    a = fopen(partition, "rb");

    while (i < limit) {
	fread(&chunk[0], 1024, 1, a);
	for (j = 0; j < 1024; j++)
	    if (chunk[j] == '\0')
		chunk[j] = ' ';

	chunk[1024] = '\0';
	if (strstr(chunk, token) != NULL) {
	    xprint(" %s found\n", token);
	    fclose(a);
	    return 1;
	}
	i++;
    }

    xprint("%s not found\n", token);
    return 0;
}

char *giveName(char *partition)
{



    int i = 0;

    char flag = 1;


    /* Check if Win9x */
    for (i = 0; i < 3; i++) {
	xprint("[identifier.c]%s:  ", TOKENS_WIN98[i]);
	if (search_token(TOKENS_WIN98[i], partition))
	    flag *= 1;
	else
	    flag = 0;

    }
    if (flag) {
	xprint("[identifier.c]Win9x System\n");
	return SYSTEM_TYPE[2];
    }


    /* Check if Win NT/XP */
    flag = 1;
    for (i = 0; i < 3; i++) {
	xprint("[identifier.c]%s:  ", TOKENS_FAT32_WINXP[i]);
	if (search_token(TOKENS_FAT32_WINXP[i], partition))
	    flag *= 1;
	else
	    flag = 0;

    }
    if (flag) {
	xprint("[identifier.c]WinXP System\n");
	return SYSTEM_TYPE[3];
    }

    /* WinXP NTFS 32 Data */
    flag = 1;
    for (i = 0; i < 2; i++) {
	xprint("[identifier.c]%s:  ", TOKENS_NTFS_WINXP[i]);
	if (search_token(TOKENS_NTFS_WINXP[i], partition))
	    flag *= 1;
	else
	    flag = 0;

    }
    if (flag) {
	xprint("[identifier.c]WinXP NTFS Data\n");
	return SYSTEM_TYPE[6];
    }

    /* Fat 32 Data */
    flag = 1;
    for (i = 0; i < 1; i++) {
	xprint("[identifier.c]%s:  ", TOKENS_FAT32_DATA[i]);
	if (search_token(TOKENS_FAT32_DATA[i], partition))
	    flag *= 1;
	else
	    flag = 0;

    }
    if (flag) {
	xprint("[identifier.c]FAT32 Data\n");
	return SYSTEM_TYPE[4];
    }

    /* Fat 16 Data */
    flag = 1;
    for (i = 0; i < 1; i++) {
	xprint("[identifier.c]%s:  ", TOKENS_FAT16_DATA[i]);
	if (search_token(TOKENS_FAT16_DATA[i], partition))
	    flag *= 1;
	else
	    flag = 0;

    }
    if (flag) {
	xprint("[identifier.c]FAT16 Data\n");
	return SYSTEM_TYPE[4];
    }


    return SYSTEM_TYPE[0];
}
