/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "global.h"
#include "logic.h"
#include "anlz.h"
#include <math.h>

long long _MIN_SPACE = 1073741824;
long long _MAX_SPACE = 0;

char _ACTIONS[16] =
    { ACTION_NONE, ACTION_NONE, ACTION_NONE, ACTION_NONE, ACTION_NONE,
    ACTION_NONE, ACTION_NONE, ACTION_NONE, ACTION_NONE, ACTION_NONE,
	ACTION_NONE,
    ACTION_NONE, ACTION_NONE, ACTION_NONE, ACTION_NONE, ACTION_NONE
};
char _CONFACTIONS[16] =
    { CONFACTION_NONE, CONFACTION_NONE, CONFACTION_NONE, CONFACTION_NONE,
    CONFACTION_NONE, CONFACTION_NONE,
    CONFACTION_NONE, CONFACTION_NONE, CONFACTION_NONE, CONFACTION_NONE,
    CONFACTION_NONE, CONFACTION_NONE, CONFACTION_NONE, CONFACTION_NONE,
	CONFACTION_NONE, CONFACTION_NONE
};
int _N_CONFACTIONS;

char *user_face_options[16];

int _p_logic()
{

    int n_resizable_parts = 0;
    int n_replazable = 0;
    int n_holes = 0;
    int i, j = 0;

    /* Disk Status */
    /*
       #define DISK_UNKNOWN   0x00
       #define DISK_FULL      0x01
       #define DISK_WIN       0x02
       #define DISK_LIN       0x04
       #define DISK_UNPART    0x08
       #define DISK_CLEAN     0x16
       #define DISK_EMPTY     0x32
       #define DISK_FREESPACE     0x64
     */

    /*printf("%s (0x%x)\n", _i18n("Disk Status:"), _DISK_STATUS);
       if (_p_cFlag(DISK_FREESPACE))
       printf("- %s\n", _i18n("Disk has free space"));
       if (_p_cFlag(DISK_FREESPACE_CT))
       printf("- %s\n", _i18n("Disk has enough contiguous free space"));
       if (_p_cFlag(DISK_CLEAN))
       printf("- %s\n", _i18n("Disk has no partitions"));
       if (_p_cFlag(DISK_EMPTY))
       printf("- %s\n", _i18n("Disk has no partition table"));
       if (_p_cFlag(DISK_LIN))
       printf("- %s\n", _i18n("Disk seems to have a linux system"));
       if (_p_cFlag(DISK_WIN))
       printf("- %s\n", _i18n("Disk seems to have a Windows(TM) system"));
       if (_p_cFlag(DISK_FULL))
       printf("- %s\n", _i18n("Disk is full"));
       if (_p_cFlag(DISK_UNPART))
       printf("- %s\n", _i18n("No more partitions can be created"));
       if (_DISK_STATUS == DISK_UNKNOWN) {
       printf("- %s\n",
       _i18n("Disk is unknow, not present or too small"));

       }        
     */
    printf("II#Disk Status#STATUS #FRE|FRC|CLN|EMP|LIN|WIN|FUL|UNP|UNK\n");
    printf
	("II#Disk Status#VALUE  # %d | %d | %d | %d | %d | %d | %d | %d | %d\n",
	 _p_cFlag(DISK_FREESPACE), _p_cFlag(DISK_FREESPACE_CT),
	 _p_cFlag(DISK_CLEAN), _p_cFlag(DISK_EMPTY), _p_cFlag(DISK_LIN)
	 , _p_cFlag(DISK_WIN), _p_cFlag(DISK_FULL), _p_cFlag(DISK_UNPART),
	 (_DISK_STATUS == DISK_UNKNOWN));

    if (_APP_ACTION == APP_ACTION_SHOW) {
	/* Just a small list of particions */
	for (i = 0; i < _N_RAW_PARTS; i++) {
	    xprint("Checking partitions %s%d %lld-%lld\n",
		   _p_part_list[i]->disk->dev->path, _p_part_list[i]->num,
		   _MIN_SPACE, _MAX_SPACE);
	    if (_p_checkResizability(i, 0, 1)) {
		if ((resizable_partitions[0].original->geom.length *
		     _p_alldev[_N_SEL_DRIVE]->sector_size < _MAX_SPACE)
		    || (_MAX_SPACE == 0)) {
		    printf
			("\nII#%s%d#GAINED:%lld#SIZE:%lld#FS:%s#TYPE:%s\n",
			 resizable_partitions[0].major,
			 resizable_partitions[0].minor,
			 resizable_partitions[0].free_space_gained,
			 resizable_partitions[0].original->geom.length *
			 _p_alldev[_N_SEL_DRIVE]->sector_size,
			 resizable_partitions[0].original->fs_type->name,
			 luser_index[i]

			);
		    //  
		}



	    }
	}

    }
    /* VALIDATION LOGIC */
    else if (_APP_ACTION == APP_ACTION_VALIDATE) {
	xprint("Checking layout\n");
	int i = 0;
	int _N_PARTS_REQUESTED = 0;
	while (_LAYOUT[i] != 0) {
	    _N_PARTS_REQUESTED++;
	    i++;
	}
	/*There is free space and a correct hole */
	if ((_p_cFlag(DISK_FREESPACE)) && (_p_cFlag(DISK_FREESPACE_CT))) {
	    xfprint("VV#FREESPACE\n");
	    if ((5 - _p_nextFree(0)) >= _N_PARTS_REQUESTED) {
		int hj = 0;
		int sc = 0;
		do {
		    hj = _p_nextFreeOver(hj);
		    xfprint("CC#MAKE_PRIMARY_PARTITION#%d#%d\n", hj,
			    _LAYOUT[sc]);
		    sc++;
		} while (sc < _N_PARTS_REQUESTED);
	    } else if (_n_ext_parts > 0)
		if ((65 - _p_nextFree(5)) >= _N_PARTS_REQUESTED) {
		    int ji = 0;
		    int xi = 0;

		    ji = _p_findHole();
		    for (xi = 0; xi < ji; xi++) {
			if (strcmp(holes[xi].type, "primary") == 0)
			    break;
		    }
		    if ((xi + 1) == _N_PARTS_REQUESTED)
			xfprint("CC#MAKE_LOGICAL_PARTITION#%d\n",
				_N_PARTS_REQUESTED);
		    else
			xfprint("CC#NOT_POSSIBLE#%d\n",
				_N_PARTS_REQUESTED);

		} else

		    xfprint("VV#ERR#%d LOGICAL_PARTITION_NOT_POSSIBLE",
			    _N_PARTS_REQUESTED);
	    else if (_n_ext_parts < 1) {
		xfprint("CC#MAKE_EXTENDED_PARTITION#%d\n", _p_nextFree(0));

		int hj = 4;
		int sc = 0;
		do {
		    hj = _p_nextFreeOver(hj);
		    xfprint("CC#MAKE_LOGICAL_PARTITION#%d#%d\n", hj,
			    _LAYOUT[sc]);
		    sc++;
		} while (sc < _N_PARTS_REQUESTED);
	    }





	}
	/* There is no free space */
	else if (_p_cFlag(DISK_UNPART)) {
	    xfprint("VV#ERR#PARTITION_NOT_POSSIBLE DISK_UNPART\n",
		    _N_PARTS_REQUESTED);
	} else if (_p_cFlag(DISK_FULL)) {
	    xfprint("VV#WAR#NEED_RESIZING\n", _N_PARTS_REQUESTED);
	    _APP_ACTION = APP_ACTION_WIZARD;

	} else {
	    xfprint("VV#WAR#UNKNOW LAYOUT\n", _N_PARTS_REQUESTED);
	    _APP_ACTION = APP_ACTION_WIZARD;

	}

    }
    if (_APP_ACTION == APP_ACTION_WIZARD) {

	/* Decision making */

	/*There is free space and a correct hole, disk is uninialited */
	if ((_p_cFlag(DISK_FREESPACE)) && (_p_cFlag(DISK_FREESPACE_CT))
	    && (!_p_cFlag(DISK_EMPTY)) && (_p_cFlag(DISK_CLEAN))) {
	    _ACTIONS[0] = _ACTIONS[0] | ACTION_ALL_FOR_ME;
	    _ACTIONS[1] = _ACTIONS[1] | ACTION_PARTIAL_FOR_ME;
	}

	/*There is free space and a correct hole, disk has Win and no Linux */
	else if ((_p_cFlag(DISK_FREESPACE))
		 && (_p_cFlag(DISK_FREESPACE_CT))
		 && (_p_cFlag(DISK_WIN)) && (!_p_cFlag(DISK_LIN))) {
	    n_holes = _p_findHole();
	    for (i = 0; i < n_holes; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_FITME;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_WINBOOT;
	    }
	    n_resizable_parts = _p_findRes(i);
	    for (j = i; j < (n_resizable_parts + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_RESIZE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_WINBOOT;
	    }

	}

	/*There is free space and a correct hole, disk has linux and no Windows */
	else if ((_p_cFlag(DISK_FREESPACE))
		 && (_p_cFlag(DISK_FREESPACE_CT))
		 && (_p_cFlag(DISK_LIN)) && (!_p_cFlag(DISK_WIN))) {
	    n_holes = _p_findHole();
	    for (i = 0; i < n_holes; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_FITME;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_WINBOOT;
	    }
	    n_resizable_parts = _p_findRes(i);
	    for (j = i; j < (n_resizable_parts + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_RESIZE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_WINBOOT;
	    }
	}

	/*There is free space and a correct hole, disk has linux and  Windows */
	else if ((_p_cFlag(DISK_FREESPACE))
		 && (_p_cFlag(DISK_FREESPACE_CT))
		 && (_p_cFlag(DISK_LIN)) && (_p_cFlag(DISK_WIN))) {
	    n_holes = _p_findHole();
	    for (i = 0; i < n_holes; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_FITME;
		_CONFACTIONS[i] =
		    _CONFACTIONS[i] | CONFACTION_LINBOOT |
		    CONFACTION_WINBOOT;
	    }

	    n_holes = _p_findHole();
	    for (i = 0; i < n_holes; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_FITME;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_WINBOOT;
	    }
	    n_resizable_parts = _p_findRes(i);
	    for (j = i; j < (n_resizable_parts + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_RESIZE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_WINBOOT;
	    }

	}

	/*There is has freespace but no correct holes, disk has LInux  and no Windows */
	else if ((_p_cFlag(DISK_FREESPACE))
		 && (!_p_cFlag(DISK_FREESPACE_CT))
		 && (!_p_cFlag(DISK_UNPART)) && (_p_cFlag(DISK_LIN))
		 && (!_p_cFlag(DISK_WIN))) {

	    n_resizable_parts = _p_findRes(j);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_LINBOOT;
	    }
	    n_replazable = _p_findReplazable(n_resizable_parts);
	    for (j = i; j < (n_replazable + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_LINBOOT;
	    }
	}

	/*There is has freespace but no correct holes, disk has Windows and no Linux */
	else if ((_p_cFlag(DISK_FREESPACE))
		 && (!_p_cFlag(DISK_FREESPACE_CT))
		 && (!_p_cFlag(DISK_UNPART)) && (_p_cFlag(DISK_WIN))
		 && (!_p_cFlag(DISK_LIN))) {

	    n_resizable_parts = _p_findRes(j);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_WINBOOT;
	    }

	}

	/*There is has freespace and correct holes, disk hasn't Windows neither Linux */

	else if ((_p_cFlag(DISK_FREESPACE))
		 && (_p_cFlag(DISK_FREESPACE_CT))
		 && (!_p_cFlag(DISK_UNPART)) && (!_p_cFlag(DISK_LIN))
		 && (!_p_cFlag(DISK_WIN)) && (!_p_cFlag(DISK_CLEAN))) {
	    n_holes = _p_findHole();
	    for (i = 0; i < n_holes; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_FITME;

	    }

	}

	/*There is has freespace but no correct holes, disk has Windows and Linux */

	else if ((_p_cFlag(DISK_FREESPACE))
		 && (!_p_cFlag(DISK_FREESPACE_CT))
		 && (!_p_cFlag(DISK_UNPART)) && (_p_cFlag(DISK_LIN))
		 && (_p_cFlag(DISK_WIN))) {
	    n_resizable_parts = _p_findRes(j);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] =
		    _CONFACTIONS[i] | CONFACTION_LINBOOT |
		    CONFACTION_WINBOOT;
	    }

	    n_replazable = _p_findReplazable(n_resizable_parts);
	    for (j = i; j < (n_replazable + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_LINBOOT;
	    }

	}

	/*There is full but new partitions can be added, disk hasn't LInux  and no Windows */
	else if ((_p_cFlag(DISK_FULL)) && (!_p_cFlag(DISK_UNPART))
		 && (!_p_cFlag(DISK_LIN)) && (!_p_cFlag(DISK_WIN))) {

	    n_resizable_parts = _p_findRes(0);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_LINBOOT;
	    }

	    n_replazable = _p_findReplazable(n_resizable_parts);
	    for (j = i; j < (n_replazable + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_LINBOOT;
	    }

	}

	/*There is full but new partitions can be added, disk has LInux  and no Windows */
	else if ((_p_cFlag(DISK_FULL)) && (!_p_cFlag(DISK_UNPART))
		 && (_p_cFlag(DISK_LIN)) && (!_p_cFlag(DISK_WIN))) {

	    n_resizable_parts = _p_findRes(0);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_LINBOOT;
	    }

	    n_replazable = _p_findReplazable(n_resizable_parts);
	    for (j = i; j < (n_replazable + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		_CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_LINBOOT;
	    }

	}

	/*There is full but new partitions can be added, disk has Windows and no Linux */
	else if ((_p_cFlag(DISK_FULL)) && (!_p_cFlag(DISK_UNPART))
		 && (_p_cFlag(DISK_WIN)) && (!_p_cFlag(DISK_LIN))) {

	    n_resizable_parts = _p_findRes(j);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] = _CONFACTIONS[i] | CONFACTION_WINBOOT;
	    }
	}

	/*There is full but new partitions can be added, disk has Windows and Linux */

	else if ((_p_cFlag(DISK_FULL)) && (!_p_cFlag(DISK_UNPART))
		 && (_p_cFlag(DISK_LIN)) && (_p_cFlag(DISK_WIN))) {

	    n_resizable_parts = _p_findRes(0);
	    for (i = 0; i < n_resizable_parts; i++) {
		_ACTIONS[i] = _ACTIONS[i] | ACTION_RESIZE;
		_CONFACTIONS[i] =
		    _CONFACTIONS[i] | CONFACTION_LINBOOT |
		    CONFACTION_WINBOOT;
	    }

	    n_replazable = _p_findReplazable(n_resizable_parts);
	    for (j = i; j < (n_replazable + i); j++) {
		_ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		_CONFACTIONS[j] =
		    _CONFACTIONS[j] | CONFACTION_LINBOOT |
		    CONFACTION_WINBOOT;;
	    }
	}

	/* Unknow Partition table signature */
	else if ((_p_cFlag(DISK_EMPTY))) {
	    _ACTIONS[0] =
		_ACTIONS[0] | ACTION_ALL_FOR_ME | ACTION_CREATE_PART_TABLE;
	    _ACTIONS[1] =
		_ACTIONS[1] | ACTION_PARTIAL_FOR_ME |
		ACTION_CREATE_PART_TABLE;
	}

	/* No more partitions can be added */

	else if ((_p_cFlag(DISK_UNPART))) {
	    _ACTIONS[0] = _ACTIONS[0] | ACTION_MAKEMYDAY;

	    /* has linux no hasefroch */
	    if ((_p_cFlag(DISK_LIN)) && (!_p_cFlag(DISK_WIN))) {
		n_replazable = _p_findReplazable(0);
		for (j = 1; j < (n_replazable + 1); j++) {
		    _ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		    _CONFACTIONS[j] = _CONFACTIONS[j] | CONFACTION_LINBOOT;
		}
	    }
	    /* has linux and hasefroch */
	    if ((_p_cFlag(DISK_LIN)) && (_p_cFlag(DISK_WIN))) {
		n_replazable = _p_findReplazable(1);
		for (j = 1; j < (n_replazable + 1); j++) {
		    _ACTIONS[j] = _ACTIONS[j] | ACTION_REPLACE;
		    _CONFACTIONS[j] =
			_CONFACTIONS[j] | CONFACTION_LINBOOT |
			CONFACTION_WINBOOT;
		}
	    }

	}

	return 1;
    }
}


int _p_show_actions()
{

    int i, op;
    int j = 0;
    int action_to_perform;
    long long min;
    long long max;
    double MB_MIN_SPACE;
    double MB_MAX_SPACE;

    xprint("#%s\n", _i18n("Actions to perform:"));
    for (i = 0; i < 16; i++) {
	if (_ACTIONS[i] != ACTION_NONE) {
	    xprint("\n(OO)0x%x-%d", _ACTIONS[i], i);
	    j++;
	    user_face_options[i] = (char *) malloc(1024);
	    if (_p_cAction(ACTION_CREATE_PART_TABLE, _ACTIONS[i])) {
		xprint("\n%s ", _i18n("Make partition table."));
		xprint("\n\tparted -s %s mklabel msdos",
		       &_SELECTED_DRIVE[0]);

		sprintf(&user_face_options[i][0], "%s ",
			_i18n("Make partition table."));

	    }

	    if (_p_cAction(ACTION_ALL_FOR_ME, _ACTIONS[i])) {
		xprint("\n%s ", _i18n("New partition. All space."));
		xprint("\n\tparted -s %s mkpart primary 0 %.3f",
		       &_SELECTED_DRIVE[0],
		       (double) (_p_alldev[_N_SEL_DRIVE]->length *
				 _p_alldev[_N_SEL_DRIVE]->sector_size /
				 _MEGABYTE_FACTOR));
		xprint("\n\tmkfs.ext3-O has_journal,filetype  %s1\n",
		       &_SELECTED_DRIVE[0]);

		sprintf(&user_face_options[i][0], "%s ",
			_i18n("New partition. All space."));

	    }
	    if (_p_cAction(ACTION_PARTIAL_FOR_ME, _ACTIONS[i])) {
		xprint("\n%s ", _i18n("New partition. Leave free space."));
		xprint("\n\tparted -s %s mkpart primary 0 %.3f",
		       &_SELECTED_DRIVE[0],
		       (double) (_MIN_SPACE / _MEGABYTE_FACTOR));
		xprint("\n\tmkfs.ext3 -O has_journal,filetype %s1\n",
		       &_SELECTED_DRIVE[0]);

		sprintf(&user_face_options[i][0], "%s ",
			_i18n("New partition. Leave free space."));

	    }
	    if (_p_cAction(ACTION_FITME, _ACTIONS[i])) {
		xprint("\n%s ",
		       _i18n
		       ("New partition. Adapt to existing partition scheme."));
		if (holes[i].next_free < 5)
		    xprint("\n\tparted -s %s mkpart primary %.3f %.3f",
			   holes[i].major, holes[i].startMB,
			   holes[i].endMB);
		else
		    xprint("\n\tparted -s %s mkpart logical %.3f %.3f",
			   holes[i].major, holes[i].startMB,
			   holes[i].endMB);

		xprint("\n\tmkfs.ext3 -O has_journal,filetype %s",
		       holes[i].major, holes[i].next_free);

		sprintf(&user_face_options[i][0], "%s %s (%lld-%lld)",
			_i18n
			("New partition. Adapt to existing partition scheme using "),
			unix_device_translate(holes[i].major,
					      holes[i].next_free),
			holes[i].startMB, holes[i].endMB);

	    }
	    if (_p_cAction(ACTION_RESIZE, _ACTIONS[i])) {
		xprint("\n%s %s%d %s ",
		       _i18n
		       ("Resize"), resizable_partitions[i].major,
		       resizable_partitions[i].minor, _i18n("to"));
		xprint("%f %s",
		       resizable_partitions[i].new_endMB -
		       resizable_partitions[i].new_startMB, _i18n("MiB"));
		xprint("\n%s %s %s %s %s %lld",
		       _i18n("Make smaller"),
		       unix_device_translate(resizable_partitions[i].major,
					     resizable_partitions[i].
					     minor),
		       _i18n("I think is a "),
		       luser_index[resizable_partitions[i].
				   partition_index],
		       _i18n("system. we could gain"),
		       resizable_partitions[i].free_space_gained);

		sprintf(&user_face_options[i][0],
			"%s %s ,%s %s %s",
			_i18n
			("Make smaller"),
			unix_device_translate(resizable_partitions[i].
					      major,
					      resizable_partitions[i].
					      minor),
			_i18n("I think is a "),
			luser_index[resizable_partitions[i].
				    partition_index], _i18n("system."));

		if (resizable_partitions[i].driver == DRIVER_PARTED) {
		    xprint
			("\nCC#parted -s %s resize %d %.3f %.3f # SEC (%lld-%lld)",
			 resizable_partitions[i].major,
			 resizable_partitions[i].minor,
			 resizable_partitions[i].new_startMB,
			 resizable_partitions[i].new_endMB,
			 resizable_partitions[i].new_startSEC,
			 resizable_partitions[i].new_endSEC);
		    /* THIS IS NOT ALWAYS CORRECT CHECK! */
		    if (resizable_partitions[i].next_free < 5)
			xprint
			    ("\nCC#parted -s %s mkpart primary %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) (resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size) / _MEGABYTE_FACTOR);
		    else
			xprint
			    ("\nCC#parted -s %s mkpart logical %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) (resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size) / _MEGABYTE_FACTOR);

		    xprint
			("\nCC#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
			 resizable_partitions[i].major,
			 resizable_partitions[i].next_free);

		} else if (resizable_partitions[i].driver ==
			   DRIVER_NTFSRESIZE) {
		    xprint("\nCC#ntfsresize -s %dM %s%d ",
			   (int) (floor
				  (resizable_partitions[i].new_sizeMB)),
			   resizable_partitions[i].major,
			   resizable_partitions[i].minor);
		    xprint("\nCC#echo %lld %lld|sfdisk %s -N%d -uS -f ",
			   resizable_partitions[i].new_startSEC,
			   resizable_partitions[i].new_sizeSEC,
			   resizable_partitions[i].major,
			   resizable_partitions[i].minor);
		    xprint("\nCC#parted -s %s mkpart primary %.3f %.3f",
			   resizable_partitions[i].major,
			   resizable_partitions[i].new_endMB,
			   (double) (resizable_partitions[i].original->
				     geom.end *
				     _p_alldev[_N_SEL_DRIVE]->
				     sector_size) / _MEGABYTE_FACTOR);
		    xprint
			("\nCC#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
			 resizable_partitions[i].major,
			 resizable_partitions[i].next_free);
		} else if (resizable_partitions[i].driver ==
			   DRIVER_RESIZE2FS) {
		    xprint("\nCC#resize2fs %s%d %dM",
			   resizable_partitions[i].major,
			   resizable_partitions[i].minor,
			   (int) (floor
				  (resizable_partitions[i].new_sizeMB)));
		    xprint("\nCC#echo %lld %lld|sfdisk %s -N%d -uS  -f",
			   resizable_partitions[i].new_startSEC,
			   resizable_partitions[i].new_sizeSEC,
			   resizable_partitions[i].major,
			   resizable_partitions[i].minor);
		    xprint("\nCC#parted -s %s mkpart primary %.3f %.3f",
			   resizable_partitions[i].major,
			   resizable_partitions[i].new_endMB,
			   (double) (resizable_partitions[i].original->
				     geom.end *
				     _p_alldev[_N_SEL_DRIVE]->
				     sector_size) / _MEGABYTE_FACTOR);
		    xprint
			("\nCC#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
			 resizable_partitions[i].major,
			 resizable_partitions[i].next_free);
		}


	    }
	    if (_p_cAction(ACTION_REPLACE, _ACTIONS[i])) {
		xprint("\n%s ", _i18n("Replace an existing linux."));
		xprint("\n%s %s. %s %s",
		       _i18n("I think there's a Linux system on "),
		       unix_device_translate(replazables[i].major,
					     replazables[i].minor),
		       _i18n("System's type could be"),
		       luser_index[replazables[i].partition_index]);

		sprintf(&user_face_options[i][0], "%s %s.(%s)",
			_i18n("Replace Linux on"),
			unix_device_translate(replazables[i].major,
					      replazables[i].minor),
			luser_index[replazables[i].partition_index]);

		xprint
		    ("\nCC#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
		     replazables[i].major, replazables[i].minor);

	    }
	    if (_p_cAction(ACTION_MAKEMYDAY, _ACTIONS[i])) {
		xprint("\n%s ",
		       _i18n
		       ("No more partitions can be created, user should delete one for more actions."));
		sprintf(&user_face_options[i][0], "%s",
			_i18n
			("No more partitions can be created, user should delete one for more actions. "));

	    }

	}
	xprint("\n");
    }
    xprint("#%s\n", _i18n("Additional actions to perform:"));
    for (i = 0; i < 16; i++) {
	if (_CONFACTIONS[i] != CONFACTION_NONE) {
	    xprint("#- %s (0x%x) %s %d\t", _i18n("Additional action"),
		   _CONFACTIONS[i], _i18n("Choice"), i);
	    if (_p_cAction(CONFACTION_WINBOOT, _CONFACTIONS[i]))
		xprint("%s ", _i18n("Configure Windows boot."));
	    if (_p_cAction(CONFACTION_LINBOOT, _CONFACTIONS[i]))
		xprint("%s ", _i18n("Configure existing linux boot."));
	    xprint("\n");

	}
    }

    /* Still not finished */
    if (_BE_INTERACTIVE == 1) {
	user_face_options[j] = (char *) malloc(1024);
	strcpy(&user_face_options[j][0], _i18n("Do nothing"));

	op = DreadOption(j + 1, user_face_options,
			 _i18n("Please select a choice"));

	i = op - 1;

	xfprint("Option sel: %d Option used %d index $d\n", op, j, i);

	if (op != (j + 1)) {
	    //Let's prepare actions
	    action_to_perform = (op - 1);
	    xfprint("%s %d 0x%x\n", _i18n("Preparing for action"),
		    action_to_perform, _ACTIONS[action_to_perform]);

	    i = action_to_perform;

	    if (_p_cAction(ACTION_RESIZE, _ACTIONS[i])) {

		/* Option size */

		min = _MIN_SPACE;
		max = resizable_partitions[i].free_space_gained+resizable_partitions[i].USURPED;
                
		MB_MIN_SPACE = (double) (min / _MEGABYTE_FACTOR);

		if (_MAX_SPACE != 0)
		    MB_MAX_SPACE =
			(max >
			 _MAX_SPACE) ? ((double) (_MAX_SPACE /
						  _MEGABYTE_FACTOR))
			: ((double) (max / _MEGABYTE_FACTOR));
		else
		    MB_MAX_SPACE = (double) (max / _MEGABYTE_FACTOR);

		_MIN_SPACE =
		    Dget_in_interval((long long int) MB_MIN_SPACE,
				     (long long int) MB_MAX_SPACE,
				     _i18n("Select size for partition"));

		_MIN_SPACE *= _MEGABYTE_FACTOR;

		_MIN_SPACE-=resizable_partitions[i].USURPED;
		xfprint("%s:(%lld-%lld)\n", _i18n("Select new space"), min,
			max);

		_p_checkResizability(resizable_partitions[i].
				     partition_index, i, 1);

		if (resizable_partitions[i].driver == DRIVER_PARTED) {
		    xfprint
			("\nCC#RESIZE#parted -s %s resize %d %.3f %.3f # SEC (%lld-%lld)",
			 resizable_partitions[i].major,
			 resizable_partitions[i].minor,
			 resizable_partitions[i].new_startMB,
			 resizable_partitions[i].new_endMB,
			 resizable_partitions[i].new_startSEC,
			 resizable_partitions[i].new_endSEC);
		    if (_NO_MAKE_PARTITIONS == 1) {
			xfprint("\n");
			return;
		    }
		    /* THIS IS NOT ALWAYS CORRECT CHECK! */
		    if (resizable_partitions[i].next_free < 5)
			xfprint
			    ("\nCC#MAKE_PRIMARY#parted -s %s mkpart primary %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) ((resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size)+resizable_partitions[i].USURPED) / _MEGABYTE_FACTOR);
		    else
			xfprint
			    ("\nCC#MAKE_LOGICAL#parted -s %s mkpart logical %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) ((resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size)+resizable_partitions[i].USURPED) / _MEGABYTE_FACTOR);

		    xfprint
			("\nCC#FORMAT#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
			 resizable_partitions[i].major,
			 resizable_partitions[i].next_free);

		} else if (resizable_partitions[i].driver ==
			   DRIVER_NTFSRESIZE) {
		    xfprint("\nCC#RESIZE#ntfsresize -s %dM %s%d ",
			    (int) (floor
				   (resizable_partitions[i].new_sizeMB)),
			    resizable_partitions[i].major,
			    resizable_partitions[i].minor);
		    xfprint
			("\nCC#CUT#echo %lld %lld|sfdisk %s -N%d -uS  -f",
			 resizable_partitions[i].new_startSEC,
			 resizable_partitions[i].new_sizeSEC,
			 resizable_partitions[i].major,
			 resizable_partitions[i].minor);
		    if (_NO_MAKE_PARTITIONS == 1) {
			xfprint("\n");
			return;
		    }

		    if (resizable_partitions[i].next_free < 5)
			xfprint
			    ("\nCC#MAKE_PRIMARY#parted -s %s mkpart primary %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) ((resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size)+resizable_partitions[i].USURPED) / _MEGABYTE_FACTOR);
		    else
			xfprint
			    ("\nCC#MAKE_LOGICAL#parted -s %s mkpart logical %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) ((resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size)+resizable_partitions[i].USURPED) / _MEGABYTE_FACTOR);
		    xfprint
			("\nCC#FORMAT#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
			 resizable_partitions[i].major,
			 resizable_partitions[i].next_free);
		} else if (resizable_partitions[i].driver ==
			   DRIVER_RESIZE2FS) {
		    xfprint("\nCC#RESIZE#resize2fs %s%d %dM",
			    resizable_partitions[i].major,
			    resizable_partitions[i].minor,
			    (int) (floor
				   (resizable_partitions[i].new_sizeMB)));
		    xfprint
			("\nCC#CUT#echo %lld %lld|sfdisk %s -N%d -uS  -f",
			 resizable_partitions[i].new_startSEC,
			 resizable_partitions[i].new_sizeSEC,
			 resizable_partitions[i].major,
			 resizable_partitions[i].minor);
		    if (_NO_MAKE_PARTITIONS == 1) {
			xfprint("\n");
			return;
		    }

		    if (resizable_partitions[i].next_free < 5)
			xfprint
			    ("\nCC#MAKE_PRIMARY#parted -s %s mkpart primary %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) ((resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size)+resizable_partitions[i].USURPED) / _MEGABYTE_FACTOR);
		    else
			xfprint
			    ("\nCC#MAKE_LOGICAL#parted -s %s mkpart logical %.3f %.3f",
			     resizable_partitions[i].major,
			     resizable_partitions[i].new_endMB,
			     (double) ((resizable_partitions[i].original->
				       geom.end *
				       _p_alldev[_N_SEL_DRIVE]->
				       sector_size)+resizable_partitions[i].USURPED) / _MEGABYTE_FACTOR);
		    xfprint
			("\nCC#FORMAT#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
			 resizable_partitions[i].major,
			 resizable_partitions[i].next_free);
		}



	    }

	    if (_p_cAction(ACTION_REPLACE, _ACTIONS[i])) {

		xfprint
		    ("\nCC#FORMAT#mkfs.ext3 -O has_journal,filetype,^sparse_super %s%d",
		     replazables[i].major, replazables[i].minor);

	    }

	    if (_p_cAction(ACTION_MAKEMYDAY, _ACTIONS[i])) {
		xfprint("\nCC#BOGUS#%s ",
			_i18n
			("User must rearrange partition scheme, no more partitions can be created, user should delete one."));
	    }

	    if (_p_cAction(ACTION_CREATE_PART_TABLE, _ACTIONS[i])) {
		xfprint("\nCC#MAKE_PTABLE#parted -s %s mklabel msdos",
			&_SELECTED_DRIVE[0]);

	    }

	    if (_p_cAction(ACTION_ALL_FOR_ME, _ACTIONS[i])) {

		xfprint
		    ("\nCC#MAKE_PRIMARY#parted -s %s mkpart primary 0 %.3f",
		     &_SELECTED_DRIVE[0],
		     (double) (_p_alldev[_N_SEL_DRIVE]->length *
			       _p_alldev[_N_SEL_DRIVE]->sector_size /
			       _MEGABYTE_FACTOR));
		xfprint
		    ("\nCC#FORMAT#mkfs.ext3 -O has_journal,filetype,^sparse_super  %s1\n",
		     &_SELECTED_DRIVE[0]);

	    }

	    if (_p_cAction(ACTION_PARTIAL_FOR_ME, _ACTIONS[i])) {

		min = _MIN_SPACE;
		max =
		    _p_alldev[_N_SEL_DRIVE]->length *
		    _p_alldev[_N_SEL_DRIVE]->sector_size;

		MB_MIN_SPACE = (double) (min / _MEGABYTE_FACTOR);
		MB_MAX_SPACE = (double) (max / _MEGABYTE_FACTOR);

		_MIN_SPACE =
		    Dget_in_interval((long long int) MB_MIN_SPACE,
				     (long long int) MB_MAX_SPACE,
				     _i18n("Select size for partition"));

		_MIN_SPACE *= _MEGABYTE_FACTOR;

		xfprint
		    ("\nCC#MAKE_PRIMARY#parted -s %s mkpart primary 0 %.3f",
		     &_SELECTED_DRIVE[0],
		     (double) (_MIN_SPACE / _MEGABYTE_FACTOR));
		xfprint
		    ("\nCC#FORMAT#mkfs.ext3 -O -O has_journal,filetype,^sparse_super %s1\n",
		     &_SELECTED_DRIVE[0]);

	    }
	    if (_p_cAction(ACTION_FITME, _ACTIONS[i])) {

		double MB_MIN_SPACE, _SIZE, MB_MAX_SPACE;

		MB_MIN_SPACE = (double) (_MIN_SPACE / _MEGABYTE_FACTOR);
		max=holes[i].sizeSEC*_p_alldev[_N_SEL_DRIVE]->
				     sector_size;
		if (_MAX_SPACE != 0)
		    MB_MAX_SPACE =
			(max >
			 _MAX_SPACE) ? ((double) (_MAX_SPACE /
						  _MEGABYTE_FACTOR))
			: ((double) (max / _MEGABYTE_FACTOR));
		else
		    MB_MAX_SPACE = (double) (max / _MEGABYTE_FACTOR);

		_SIZE = Dget_in_interval((long long int) MB_MIN_SPACE,
					 (long long int) MB_MAX_SPACE,
					 _i18n
					 ("Select size for partition"));

		if (holes[i].next_free < 5)
		    xfprint
			("\nCC#MAKE_PRIMARY#parted -s %s mkpart primary %.3f %.3f",
			 holes[i].major, holes[i].startMB,
			 holes[i].startMB + _SIZE);
		else
		    xfprint
			("\nCC#MAKE_LOGICAL#parted -s %s mkpart logical %.3f %.3f",
			 holes[i].major, holes[i].startMB,
			 holes[i].startMB + _SIZE);

		xfprint
		    ("\nCC#FORMAT#mkfs.ext3 -O has_journal,filetype,^sparse_super  %s%d",
		     holes[i].major, holes[i].next_free);

	    }

	}

	else
	    xfprint("%s\n", _i18n("Doing nothing"));

	xfprint("\n");
    } else {
	int hj;
	printf("\n");
	for (hj = 0; hj < 16; hj++) {
	    if (_ACTIONS[hj] != ACTION_NONE)
		printf("OO#%d#%s\n", hj + 1, &user_face_options[hj][0]);
	}

    }
}
