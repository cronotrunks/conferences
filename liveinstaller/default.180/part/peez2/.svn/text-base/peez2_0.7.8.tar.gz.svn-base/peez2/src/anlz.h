/***************************************************************************
                          anlz.h  -  description
                             -------------------
    begin                : mar ene 11 2005
    copyright            : (C) 2005 by Augusto Beiro
    email                : abeiro@activasistemas.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <parted/parted.h>
#include <parted/device.h>
#include <parted/disk.h>
#include <parted/filesys.h>

#define DRIVER_PARTED 1
#define DRIVER_NTFSRESIZE 2
#define DRIVER_RESIZE2FS 4
#define DRIVER_OTHER 128

extern int _p_anlz();
extern int _p_cFlag(char flag);
extern int _p_findRes(int j);
extern int _p_findHole();
extern int _p_findReplazable(int j);
extern int _p_checkResizability(int i, int x, char force_index);
extern int _p_nextFree(int resized);
extern int _p_nextFreeOver(int resized);

extern PedPartition **_p_part_list;
extern PedDevice **_p_alldev;
extern long long CYLINDER_BOUNDARY_OVERHEAD;

typedef struct __resizable_partition {
    int partition_index;
    long long int free_space_gained;
    long long max_free_space_gained;
    long long new_startSEC;
    long long new_endSEC;
    long long new_sizeSEC;
    long long USURPED;
    double new_startMB;
    double new_endMB;
    double new_sizeMB;
    char major[256];
    int minor;
    char driver;
    PedPartition *original;
    int next_free;

} _resizable_partition;

typedef struct __hole {
    int partition_index;
    long long startSEC;
    long long endSEC;
    long long sizeSEC;
    double startMB;
    double endMB;
    double sizeMB;
    char major[256];
    int minor;
    char type[32];
    PedPartition *original;
    int next_free;
} _hole;

extern _resizable_partition resizable_partitions[];
extern _hole holes[];
extern _hole replazables[];

extern int _n_primary_parts ;
extern int _n_logical_parts ;
extern int _n_free_parts;
extern int _n_ext_parts ;
extern int _n_win_parts ;
extern int _n_lin_parts ;
extern int _n_misc_parts ;
