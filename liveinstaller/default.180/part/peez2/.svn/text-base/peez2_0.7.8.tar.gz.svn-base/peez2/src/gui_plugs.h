/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef _PLUGIN_INFO
#define _PLUGIN_INFO

typedef struct plugin_info_tag {

    char nombre[128];
    int version[3];
    char autor[128];
    int fecha[3];
    char info[1024];
    char fich[2048];
    char extension[1024];
} plugin_info;

extern plugin_info *plugins;
extern int numero_plugins;
extern char **extensiones;

extern int Dsearch_plugs(char *dir, plugin_info * plug_tag);
extern int Dgui_plug_search(char **argv);
extern int DreadLine(char *prompt, char *result);
extern long long int Dget_in_interval(long long int min, long long int max,
                                      char *prompt);
extern int DprogressBar(char *msg, float percent);
#endif
